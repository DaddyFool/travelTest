<?php
/**
* ST Check Out
* @since 1.1.0
* @author 1.1.1
* @contribute
**/
//if(function_exists('vc_map')){
//    vc_map(
//        array(
//            'name' => __("ST Check Out", ST_TEXTDOMAIN),
//            'base' => 'st_checkout',
//            'content_element' => true,
//            'icon' => 'icon-st',
//            'category' => 'Shinetheme',
//            'show_settings_on_create' => false,
//            'params'=>array()
//        )
//    );
//}
//if(!function_exists('st_sc_checkout'))
//{
//    function st_sc_checkout($attr=array(),$content=false)
//    {
//        return st()->load_template('checkout/html');
//    }
//}
//st_reg_shortcode('st_checkout','st_sc_checkout');